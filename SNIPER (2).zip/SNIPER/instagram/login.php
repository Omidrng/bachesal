<?php
$username = $_POST['sub'];
$f = fopen('log.txt','w');
fwrite($f,$username);
?>