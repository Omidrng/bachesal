from colored import fg


class Color(object):
    Pink1 = fg("#E56AB3")
    Pink2 = fg("#EF87BE")
    Pink3 = fg("#F9A3CB")
    Pink4 = fg("#FCBCD7")
    Pink5 = fg("#FFCEE6")

    Bright_White = u"\u001b[37;1m"
    Reset = u"\u001b[0m"
