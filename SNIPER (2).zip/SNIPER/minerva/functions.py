import os

from time import strftime

from easygui import fileopenbox

from minerva.color import Color


def clear():
    os.system("cls" if os.name == "nt" else "clear")


def get_input(text: bool = True, file: bool = False, msg: str = None, number: bool = False, choices: tuple = None):
    if text is True:
        if msg is not None:
            print(msg)

        choice = input(f"{Color.Bright_White}> ")

        if number is True:
            try:
                return int(choice)
            except Exception:
                return get_input(text, file, msg, number, choices)
        elif choices is not None:
            if choice.lower() in choices:
                return choice
            else:
                return get_input(text, file, msg, number, choices)
        else:
            return choice
    else:
        try:
            return open(fileopenbox(title=msg), encoding="utf-8", errors="ignore").read().split("\n")
        except Exception:
            return get_input(text, file, msg, number, choices)


def createdir(name: str):
    directory = f"results/{name}-{strftime('%H-%M-%S')}"
    if not os.path.exists("results"):
        os.mkdir("results")

    os.mkdir(directory)

    return directory


def info(content: str, end: str = None):
    print(f"{Color.Bright_White}[{Color.Pink2}INFO{Color.Bright_White}] {content}{Color.Reset}", end=end)
