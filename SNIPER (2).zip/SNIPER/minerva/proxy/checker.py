import time
import threading

import asyncio

from aiohttp import ClientSession
from aiohttp_proxy import ProxyConnector, ProxyType


class Checker(object):
    def __init__(self, proxies: list, proxy_type: str, threads: int, timeout: int, savedir: str):
        # Arguments:
        self.proxies = set(proxies)
        self.threads = threads
        self.timeout = timeout
        self.savedir = savedir

        proxy_type = proxy_type.lower()

        if proxy_type not in ("http", "https", "socks4", "socks5"):
            raise ValueError("`proxy_type` must be either http, https, socks4, or socks5")

        if proxy_type == "http":
            self.proxy_type = ProxyType.HTTP
        elif proxy_type == "https":
            self.proxy_type = ProxyType.HTTPS
        elif proxy_type == "socks4":
            self.proxy_type = ProxyType.SOCKS4
        else:
            self.proxy_type = ProxyType.SOCKS5

        # Counters:
        self.good = 0
        self.bad = 0
        self.checked = 0
        self.total = len(self.proxies)
        self.start_time = 0
        self.cpm = 0
        self.elapsed = 0

        # Thread Lock:
        self.lock = asyncio.Lock()

        # Running:
        self.running = False

    def parse_proxy(self, proxy):
        spl = proxy.split(":")

        return ProxyConnector(
            host=spl[0],
            port=int(spl[1]),
            proxy_type=self.proxy_type,
            username=None if len(spl) != 4 else spl[2],
            password=None if len(spl) != 4 else spl[3]
        )

    async def check(self, proxy):
        try:
            async with ClientSession(connector=self.parse_proxy(proxy)) as session:
                async with session.get("http://httpbin.org/ip", timeout=self.timeout) as response:
                    if response.ok:
                        async with self.lock:
                            open(self.savedir, "a", encoding="utf-8", errors="ignore").write(f"{proxy}\n")
                        self.good += 1
                    else:
                        self.bad += 1
        except ConnectionResetError:
            self.bad += 1
        except Exception:
            self.bad += 1

        self.checked += 1

    async def worker(self, queue: asyncio.Queue):
        while self.running:
            try:
                proxy = queue.get_nowait()
            except asyncio.QueueEmpty:
                return
            await self.check(proxy)
            queue.task_done()

    def stop_thread(self):
        while True:
            time.sleep(1)
            if self.total == self.checked:
                self.running = False
                return

    def cpm_counter(self):
        while self.running:
            run_time = int(time.time()) - self.start_time
            if run_time > 0:
                self.cpm = int(self.checked / run_time) * 60
            time.sleep(0.05)

    def elapsed_counter(self):
        while self.running:
            self.elapsed = time.strftime('%H:%M:%S', time.gmtime(int(time.time() - self.start_time)))
            time.sleep(0.5)

    def start(self):
        asyncio.set_event_loop(asyncio.ProactorEventLoop())

        self.running = True
        self.start_time = int(time.time())

        threading.Thread(target=self.stop_thread, daemon=True).start()
        threading.Thread(target=self.elapsed_counter, daemon=True).start()
        threading.Thread(target=self.cpm_counter, daemon=True).start()

        queue = asyncio.Queue()

        for proxy in self.proxies:
            queue.put_nowait(proxy)

        loop = asyncio.get_event_loop()
        loop.run_until_complete(asyncio.gather(*[self.worker(queue) for _ in range(self.threads)]))
        loop.close()
