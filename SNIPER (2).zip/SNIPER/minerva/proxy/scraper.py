import re

import asyncio

from aiohttp import ClientSession


class Scraper(object):
    def __init__(self, proxy_type: str, savedir: str):
        self.savedir = savedir
        self.proxy_type = proxy_type.lower()
        self.proxies = []

        if self.proxy_type not in ("http", "socks4", "socks5", "all"):
            raise ValueError("`proxy_type` must be http, socks4, socks5, or all")

        self.sources = {
            "http": (
                "https://www.proxyscan.io/download?type=http",
                "https://www.proxyscan.io/download?type=https",
                "https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all"
                "&anonymity=all",
                "https://raw.githubusercontent.com/KUTlime/ProxyList/main/ProxyList.txt",
                "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt",
                "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
                "https://raw.githubusercontent.com/Volodichev/proxy-list/main/http_old.txt",
                "https://raw.githubusercontent.com/Volodichev/proxy-list/main/http.txt",
                "https://raw.githubusercontent.com/Volodichev/proxy-list/main/hproxy.txt",
                "https://raw.githubusercontent.com/Volodichev/proxy-list/main/aproxy.txt",
                "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
                "https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
                "https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt",
                "https://raw.githubusercontent.com/hendrikbgr/Free-Proxy-Repo/master/proxy_list.txt",
                "https://raw.githubusercontent.com/proxiesmaster/Free-Proxy-List/main/proxies.txt"
            ),
            "socks4": (
                "https://www.proxyscan.io/download?type=socks4",
                "https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks4&timeout=10000&country=all",
                "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt",
                "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt",
                "https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS4_RAW.txt",
                "https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks4.txt"
            ),
            "socks5": (
                "https://www.proxyscan.io/download?type=socks5",
                "https://api.proxyscrape.com/v2/?request=getproxies&protocol=socks5&timeout=10000&country=all",
                "https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt",
                "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt",
                "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt",
                "https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS5_RAW.txt",
                "https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks5.txt"
            )
        }
        self.regex = r"""(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{2,5})"""
        self.running = False

    async def scrape(self, site):
        try:
            async with ClientSession() as session:
                async with session.get(site, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"}) as response:
                    text = await response.text()
                    proxies = re.findall(self.regex, text)
                    if len(proxies) > 0:
                        self.proxies += proxies
        except Exception:
            pass

    def start(self):
        asyncio.set_event_loop(asyncio.ProactorEventLoop())

        self.running = True

        if self.proxy_type == "all":
            sources = self.sources["http"] + self.sources["socks4"] + self.sources["socks5"]
        else:
            sources = self.sources[self.proxy_type]

        loop = asyncio.get_event_loop()
        loop.run_until_complete(asyncio.gather(*[self.scrape(site) for site in sources]))

        open(self.savedir, "w", encoding="utf-8", errors="ignore").write("\n".join(set(self.proxies)))

        self.running = False
        loop.close()
